<form action="" method="post" enctype="multipart/form-data">
    <div class="main-content">
        <div class="col-md-6">
            <label class="form-label" for="categoryName">Category Name</label>
            <input class="form-control" type="text" name="categoryName" id="categoryName">
        </div>
        <div class="col-md-6">
            <div class="text-right">
                <input class="btn-danger m-5" type="submit" name="addCategory_submit" value="Add">
            </div>
        </div>
    </div>
</form>